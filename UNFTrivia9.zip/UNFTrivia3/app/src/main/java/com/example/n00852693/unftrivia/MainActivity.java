package com.example.n00852693.unftrivia;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;

import android.widget.Button;
import android.widget.TextView;
import android.content.Intent;



public class MainActivity extends AppCompatActivity {
    private TextView mQuestionTV;
    private TextView mAnswerTV;
    private int mCurrentIndex;
    private int [] mQuestionBank = new int [] { R.string.question_text1, R.string.question_text2, R.string.question_text3};
    public boolean [] mAnswerBank = new boolean [] {true , false , true };
    private Button mTrueButton;
    private Button mFalseButton;
    private Button mNextButton;
    private Button mHintButton;
    private static final String KEY_INDEX = "index";
    public boolean currentAnswer = mAnswerBank[mCurrentIndex];
    private boolean mIsHintShown;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        mCurrentIndex=0;

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
        mQuestionTV = (TextView) findViewById(R.id.question_textView);

        if (savedInstanceState != null) {
            mCurrentIndex = savedInstanceState.getInt(KEY_INDEX);
            mQuestionTV.setText(mQuestionBank[mCurrentIndex]);
        } else {
            mQuestionTV.setText(R.string.question_text1);
        }

        mAnswerTV = (TextView) findViewById(R.id.answer_textView);

        mTrueButton = (Button) findViewById(R.id.true_button);
        mTrueButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mIsHintShown){
                    mAnswerTV.setText("You know the answer");
                }
                else if (mAnswerBank[mCurrentIndex] == true) {
                    mAnswerTV.setText(R.string.correct_text);
                    mAnswerTV.setTextColor(0xFF00FF00);
                } else {
                    mAnswerTV.setText(R.string.incorrect_text);
                    mAnswerTV.setTextColor(0xFFFF0000);
                }

            }
        });

        mFalseButton = (Button) findViewById(R.id.false_button);
        mFalseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mIsHintShown){
                    mAnswerTV.setText("You know the answer");
                }
                else if (mAnswerBank[mCurrentIndex] == false) {
                    mAnswerTV.setText(R.string.correct_text);
                    mAnswerTV.setTextColor(0xFF00FF00);
                } else {
                    mAnswerTV.setText(R.string.incorrect_text);
                    mAnswerTV.setTextColor(0xFFFF0000);
                }

            }
        });

        mNextButton = (Button) findViewById(R.id.next_button);
        mNextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mIsHintShown = false;
                if (mCurrentIndex == 2) {
                    mCurrentIndex = 0;
                } else {
                    mCurrentIndex++;
                }
                mQuestionTV.setText(mQuestionBank[mCurrentIndex]);
                mAnswerTV.setText(R.string.answer_text);
                mAnswerTV.setTextColor(0xFF808080);

            }
        });

        mHintButton = (Button) findViewById(R.id.hint_button);
        mHintButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this , HintActivity.class );

                boolean answerIsTrue = mAnswerBank[mCurrentIndex]; i.putExtra(HintActivity.EXTRA_ANSWER, answerIsTrue);

                startActivityForResult(i, 0);

            }



    });







    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onSaveInstanceState(Bundle savedInstanceState) {
        super .onSaveInstanceState(savedInstanceState);
        savedInstanceState.putInt(KEY_INDEX, mCurrentIndex);

    }

    @Override
    protected void onActivityResult(int requestCode, int resulCode, Intent data)
    {
        if (data == null ) return ;
        mIsHintShown = data.getBooleanExtra(HintActivity.EXTRA_ANSWER_SHOWN, false );
    }

}
